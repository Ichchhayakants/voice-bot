from plivo import RestClient
from app.config.settings import *
AUTH_ID = Plivo_ID
AUTH_TOKEN = Plivo_token

PLIVO_NUMBER = "+918031138489"   # your Plivo number

def make_call(customer_number):
    client = RestClient(AUTH_ID, AUTH_TOKEN)

    response = client.calls.create(
        from_=PLIVO_NUMBER,
        to_=customer_number,
        answer_url="https://acorned-retral-adelynn.ngrok-free.dev/answer",
        answer_method="GET"
    )

    print("📞 Call initiated:", response)

if __name__ == "__main__":
    make_call("+919732651232")
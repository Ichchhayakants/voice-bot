
import asyncio
import websockets
import json
import time
import audioop
import httpx
DEEPGRAM_API_KEY = "a7ecbada2686c9ac287cb5b6d1c5e228b54ee1ce"

class DeepgramSTTStream:
    def __init__(self):
        self.detected_lang = "hi-IN"

        self._callback = None
        self._loop = None

        self._buffer = bytearray()
        self._min_bytes = 3200             ##### 8000

        self._processing = False
        self._silence_task = None

        # ✅ Transcript handling
        self._full_transcript = ""
        self._last_transcript = ""

        # ✅ FINAL control
        self._final_timer = None
        self._final_sent = False
        self._last_final_time = 0

    def set_callback(self, callback, loop):
        self._callback = callback
        self._loop = loop

    # 🎤 Audio input
    def push_audio(self, pcm_chunk: bytes):
        self._buffer.extend(pcm_chunk)

        # Reset silence detection
        if self._silence_task:
            self._silence_task.cancel()

        if self._loop:
            self._silence_task = self._loop.call_later(
                0.35, self._force_process                   # 0.6
            )

        if self._processing:
            return

        if len(self._buffer) >= self._min_bytes:
            self._flush_buffer()

    def _force_process(self):
        if not self._processing and len(self._buffer) > 1600:
            self._flush_buffer()

    def _flush_buffer(self):
        audio_data = bytes(self._buffer)
        self._buffer = bytearray()

        if self._loop:
            asyncio.run_coroutine_threadsafe(
                self._transcribe(audio_data),
                self._loop
            )

    # 🧠 STT call
    async def _transcribe(self, audio_data: bytes):
        self._processing = True

        try:
            url = "wss://api.deepgram.com/v1/listen"

            params = {
                "model": "nova-2",
                "language": "hi",
                "encoding": "linear16",
                "sample_rate": "8000",
                "channels": "1",
                "punctuate": "true",
                "smart_format": "true",
                # "endpointing": 300  # optional
            }

            headers = {
                "Authorization": f"Token {DEEPGRAM_API_KEY}",
                "Content-Type": "audio/raw"
            }

            async with httpx.AsyncClient(timeout=6) as client:
                response = await client.post(
                    url,
                    params=params,
                    headers=headers,
                    content=audio_data
                )

            if response.status_code == 200:
                data = response.json()

                transcript = (
                    data.get("results", {})
                    .get("channels", [{}])[0]
                    .get("alternatives", [{}])[0]
                    .get("transcript", "")
                    .strip()
                )

                if transcript and transcript != self._last_transcript:
                    self._last_transcript = transcript

                    # ✅ Append chunk
                    self._full_transcript += " " + transcript
                    print(f"🎙️ Partial: '{transcript}'")

                    # Reset FINAL state
                    self._final_sent = False

                    # Cancel previous timer
                    if self._final_timer:
                        self._final_timer.cancel()

                    # Start silence timer
                    if self._loop:
                        self._final_timer = self._loop.call_later(
                            0.7, self._send_final
                        )

            else:
                print(f"❌ Deepgram error: {response.status_code}")

        except Exception as e:
            print(f"❌ STT Error: {e}")

        finally:
            self._processing = False

    # ✅ FINAL TEXT (only once)
    def _send_final(self):
        # Prevent duplicate trigger
        if self._final_sent:
            return

        # Debounce protection
        if time.time() - self._last_final_time < 0.5:
            return

        final_text = self._clean_text(self._full_transcript.strip())

        # Ignore very short text
        # if not final_text or len(final_text.split()) < 2:
        #     return

        self._final_sent = True
        self._last_final_time = time.time()

        print(f"✅ FINAL: '{final_text}'")

        if self._callback and self._loop:
            asyncio.run_coroutine_threadsafe(
                self._callback(final_text, self.detected_lang),
                self._loop
            )

        # Reset after sending
        self._full_transcript = ""
        self._last_transcript = ""

    # 🧹 Clean repeated words
    def _clean_text(self, text):
        words = text.split()
        cleaned = []

        for w in words:
            if not cleaned or cleaned[-1] != w:
                cleaned.append(w)

        return " ".join(cleaned)

    def get_text(self):
        return "", self.detected_lang

    def close(self):
        pass


def create_stt_stream():
    return DeepgramSTTStream()





























# class DeepgramSTTStream:
#     def __init__(self):
#         self.detected_lang = "hi-IN"
#         self._callback = None
#         self._loop = None
#         self._buffer = bytearray()
#         self._min_bytes = 64000
#         self._last_transcript = ""
#         self._processing = False
#         self._silence_task = None

#     def set_callback(self, callback, loop):
#         self._callback = callback
#         self._loop = loop

#     def push_audio(self, pcm_chunk: bytes):
#         self._buffer.extend(pcm_chunk)

#         if self._silence_task:
#             self._silence_task.cancel()

#         if self._loop:
#             self._silence_task = self._loop.call_later(1.2, self._force_process)

#         if self._processing:
#             return

#         if len(self._buffer) >= self._min_bytes:
#             self._flush_buffer()

#     def _force_process(self):
#         if not self._processing and len(self._buffer) > 3200:
#             self._flush_buffer()

#     def _flush_buffer(self):
#         audio_data = bytes(self._buffer)
#         self._buffer = bytearray()
#         if self._loop:
#             asyncio.run_coroutine_threadsafe(
#                 self._transcribe(audio_data),
#                 self._loop
#             )

#     async def _transcribe(self, audio_data: bytes):
#         self._processing = True
#         try:
#             url = "https://api.deepgram.com/v1/listen"
#             params = {
#                 "model": "nova-2",
#                 "language": "hi",
#                 "encoding": "linear16",
#                 "sample_rate": "8000",
#                 "channels": "1",
#                 "punctuate": "true",
#                 "smart_format": "true",
#             }
#             headers = {
#                 "Authorization": f"Token {DEEPGRAM_API_KEY}",
#                 "Content-Type": "audio/raw"
#             }
#             async with httpx.AsyncClient(timeout=6) as client:
#                 response = await client.post(
#                     url, params=params,
#                     headers=headers,
#                     content=audio_data
#                 )

#             if response.status_code == 200:
#                 data = response.json()
#                 transcript = (
#                     data.get("results", {})
#                     .get("channels", [{}])[0]
#                     .get("alternatives", [{}])[0]
#                     .get("transcript", "")
#                     .strip()
#                 )
#                 if transcript and transcript != self._last_transcript:
#                     self._last_transcript = transcript
#                     print(f"🎙️ STT: '{transcript}'")
#                     if self._loop:
#                         self._loop.call_later(3.0, self._reset_last)
#                     if self._callback and self._loop:
#                         await self._callback(transcript, self.detected_lang)
#             else:
#                 print(f"❌ Deepgram error: {response.status_code}")

#         except Exception as e:
#             print(f"❌ STT Error: {e}")
#         finally:
#             self._processing = False

#     def _reset_last(self):
#         self._last_transcript = ""

#     def get_text(self):
#         return "", self.detected_lang

#     def close(self):
#         pass

# def create_stt_stream():
#     return DeepgramSTTStream()
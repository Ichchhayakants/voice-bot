import base64
import json
import audioop
import asyncio
import time
import html
import azure.cognitiveservices.speech as speechsdk
from app.config.settings import AZURE_SPEECH_KEY, AZURE_REGION


def _build_ssml(text: str) -> str:
    safe_text = html.escape(text)

    return f"""<speak version="1.0" xml:lang="ta-IN">
  <voice name="ta-IN-PallaviNeural">
    <prosody rate="+10%" pitch="+2%">
      {safe_text}
    </prosody>
  </voice>
</speak>"""


async def _synthesize(text: str) -> bytes | None:
    try:
        speech_config = speechsdk.SpeechConfig(
            subscription=AZURE_SPEECH_KEY,
            region=AZURE_REGION
        )

        speech_config.set_speech_synthesis_output_format(
            speechsdk.SpeechSynthesisOutputFormat.Raw16Khz16BitMonoPcm
        )

        synthesizer = speechsdk.SpeechSynthesizer(
            speech_config=speech_config,
            audio_config=None
        )

        ssml = _build_ssml(text)
        loop = asyncio.get_event_loop()

        result = await loop.run_in_executor(
            None,
            lambda: synthesizer.speak_ssml_async(ssml).get()
        )

        if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
            print(f"✅ Azure Tamil TTS OK | bytes={len(result.audio_data)}")
            return result.audio_data

        if result.reason == speechsdk.ResultReason.Canceled:
            cancel = speechsdk.SpeechSynthesisCancellationDetails(result)
            print("❌ Azure Tamil TTS canceled")
            print("Reason:", cancel.reason)
            print("Error details:", cancel.error_details)
            return None

        print(f"❌ Azure Tamil TTS failed: {result.reason}")
        return None

    except Exception as e:
        print(f"❌ Tamil synthesize error: {repr(e)}")
        return None


async def send_clear_audio(plivo_ws, stream_id=None):
    if not stream_id:
        return

    try:
        await plivo_ws.send_text(json.dumps({
            "event": "clearAudio",
            "streamId": stream_id
        }))
        print("🧹 clearAudio sent")
    except Exception as e:
        print(f"⚠️ clearAudio failed: {e}")


async def _send_audio(
    pcm_16k: bytes,
    plivo_ws,
    stop_event=None,
    stream_id=None,
    playback_state=None
) -> int:
    try:
        pcm_8k, _ = audioop.ratecv(
            pcm_16k,
            2,
            1,
            16000,
            8000,
            None
        )

        ulaw_audio = audioop.lin2ulaw(pcm_8k, 2)

        # 20ms at 8kHz μ-law = 160 bytes
        chunk_size = 160
        chunk_count = 0
        t0 = time.time()

        for i in range(0, len(ulaw_audio), chunk_size):
            if stop_event and stop_event.is_set():
                print("🛑 Barge-in during Tamil TTS send")
                await send_clear_audio(plivo_ws, stream_id)
                return chunk_count

            chunk = ulaw_audio[i:i + chunk_size]
            payload = base64.b64encode(chunk).decode()

            msg = {
                "event": "playAudio",
                "media": {
                    "contentType": "audio/x-mulaw",
                    "sampleRate": 8000,
                    "payload": payload
                }
            }

            # safer for Plivo bidirectional stream
            if stream_id:
                msg["streamId"] = stream_id

            try:
                await plivo_ws.send_text(json.dumps(msg))
            except Exception as e:
                print(f"⚠️ WebSocket closed — Tamil TTS stop: {e}")
                return chunk_count

            chunk_count += 1

            if chunk_count == 1:
                print(f"⚡ First Tamil audio chunk in {time.time() - t0:.2f}s")

            # real-time pacing
            await asyncio.sleep(0.02)

        return chunk_count

    except Exception as e:
        print(f"❌ Tamil send error: {repr(e)}")
        return 0


async def stream_tts_to_plivo(
    text: str,
    plivo_ws,
    stop_event=None,
    stream_id=None,
    playback_state=None
):
    if not text or not text.strip():
        return

    print(f"🔊 Tamil TTS: {text[:80]}")

    if stop_event and stop_event.is_set():
        await send_clear_audio(plivo_ws, stream_id)
        return

    t0 = time.time()

    pcm = await _synthesize(text.strip())

    if not pcm:
        print("❌ No Tamil PCM generated, not sending audio")
        return

    total_chunks = await _send_audio(
        pcm,
        plivo_ws,
        stop_event,
        stream_id,
        playback_state
    )

    if playback_state is not None and total_chunks > 0:
        now = time.time()
        secs = total_chunks * 0.02

        if playback_state.get("until", 0) > now:
            playback_state["until"] += secs
        else:
            playback_state["until"] = now + secs

    print(f"✅ Tamil Sent ({total_chunks} chunks, {time.time() - t0:.2f}s)")
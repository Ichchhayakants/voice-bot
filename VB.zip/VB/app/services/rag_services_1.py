
from langchain_groq import ChatGroq
from app.config.settings import GROQ_API_KEY
from app.services.policy_data import get_policy_by_mobile
from app.services.System_prompt import SYSTEM_PROMPT
import re
from num2words import num2words

_llm = ChatGroq(
    api_key=GROQ_API_KEY,
    model="groq/compound",
    max_tokens=80,
    temperature=0.1
)


# _llm = ChatGroq(
#     api_key=GROQ_API_KEY,
#     model="openai/gpt-oss-20b",
#     max_tokens=130,
#     temperature=0.2
# )


_caller_histories = {}
_caller_policy_cache = {}

# keep lower history for latency
MAX_HISTORY = 4

def last4(value):
    value = str(value)
    return value[-4:] if len(value) >= 4 else value


def normalize_numbers(text: str) -> str:
    # 1. "last 4 digits" -> read one by one
    def replace_last4(match):
        digits = match.group(1)
        spoken = " ".join(num2words(int(d)) for d in digits)
        return f"last 4 digits {spoken}"

    text = re.sub(r"last 4 digits.*?(\d{4})", replace_last4, text, flags=re.IGNORECASE)

    # 2. Mobile/policy numbers -> digit by digit
    def replace_id_number(match):
        digits = match.group(2)
        spoken = " ".join(num2words(int(d)) for d in digits)
        return f"{match.group(1)}{spoken}"

    text = re.sub(
        r"((?:registered\s+)?(?:mobile|phone|policy|number|no\.?|ID)\s*(?:number|no\.?)?\s*[:,.\-]?\s*(?:(?:is|ending\s+in|ends\s+in|ending\s+with|ends\s+with)\s*)?)(\d{3,})",
        replace_id_number,
        text,
        flags=re.IGNORECASE,
    )

    # 3. Remaining numbers -> full spoken words
    def replace_number(match):
        num_str = match.group(0).replace(",", "")
        try:
            return num2words(int(num_str), lang="en_IN")
        except Exception:
            return match.group(0)

    text = re.sub(r"\d[\d,]+", replace_number, text)

    # 4. Single remaining digits -> words
    def replace_single(match):
        return num2words(int(match.group(0)))

    text = re.sub(r"\b\d\b", replace_single, text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

def normalize_tts_terms(text: str) -> str:
    replacements = {
        "PA": "Personal Accident",
        "P.A.": "Personal Accident",
        "IDV": "I D V",
        "NCB": "N C B",
        "GST": "G S T",
        "IMD": "I M D",
        "TP": "Third Party",
        "24*7": "twenty four by seven",
        "24x7": "twenty four by seven",
        "24/7": "twenty four by seven",
        "thik hai": "sure",
        "main": "mai",
        "ji sir": "",
        "sakati": "sakti",
        "badh": "increase ho",
        "hai":"hain"
        
    }

    for k, v in replacements.items():
        text = re.sub(rf"\b{re.escape(k)}\b", v, text, flags=re.IGNORECASE)

    return text

def clean_text(text: str) -> str:
    text = re.sub(r"\s+", " ", text).strip()
    text = normalize_tts_terms(text)
    if any(ch.isdigit() for ch in text):
        text = normalize_numbers(text)
        text = re.sub(r"\s+", " ", text).strip()
    return text


def _get_cached_policy_context(caller_mobile):
    if caller_mobile in _caller_policy_cache:
        return _caller_policy_cache[caller_mobile]

    policy = get_policy_by_mobile(caller_mobile)
    if not policy:
        _caller_policy_cache[caller_mobile] = "No policy data."
        return "No policy data."

    masked_mobile = " ".join(num2words(int(d)) for d in last4(caller_mobile))
    masked_policy = " ".join(num2words(int(d)) for d in last4(policy.get("policy_number")))

    # shorter context = lower prompt tokens
    ctx = (
        f"Name: {policy.get('name')}\n"
        f"PolicyType: {policy.get('policy_type')}\n"
        f"Expiry: {policy.get('expiry')}\n"
        f"Premium: {policy.get('Total_payable_amount')}\n"
        f"SumInsured: {policy.get('sum_prem')}\n"
        f"MobileLast4: {masked_mobile}\n"
        f"PolicyLast4: {masked_policy}\n"
        f"Last year Premium: Fifteen thousand rupees\n"
        f"Family members covered: You, wife (Sunita), two kids(Rahul and Riya)\n"
        f"Previous year NCB: Twenty percent \n"
        f"Current year NCB: Fifty percent \n"
    )

    _caller_policy_cache[caller_mobile] = ctx
    return ctx


def _build_messages(question, caller_mobile, lang_code):
    if caller_mobile not in _caller_histories:
        _caller_histories[caller_mobile] = []

    chat_history = _caller_histories[caller_mobile]
    policy_context = _get_cached_policy_context(caller_mobile)

    if lang_code == "en-IN":
        base_rules = """
Reply only in English (Strictly no Hindi or Hinglish).
Use 1-2 short complete sentences. MAX 25 words.
Be warm and natural for a live voice call.
Do not use any other greetings. Address the customer only as “sir” or “ji”.
Do not use Hindi, Hinglish, or Devanagari.
Never reveal full mobile or policy number; use only the last 4 digits, speak digit by digit if asked. (CRITICAL)
Do not restart after hello/ok/haan/ji; treat short replies as continuation of previous context and avoid unnecessary questions.
Use only given policy data. Never estimate, assume, or fabricate.
Do NOT repeat the same sentence or information unnecessarily (CRITICAL FAILURE)
Do NOT fall in the loop, understand customer's statement, and give response contextually
DONT mention last year premium unless customer specifically asks for it. 

CRITICAL:
If the conversation has already started, never introduce yourself again.
Never say 'Hello sir, this is Rahul...' again unless it is the first turn of the call.
If the customer says only a filler word like hello, hi, ok, haan, ji, hmm:
respond briefly based on the previous turn, or say nothing new.
"""
        prompt_body = SYSTEM_PROMPT
    else:
        base_rules = """
Reply only in Hinglish using Roman script. (MUST)

Use casual Hinglish + English mix naturally. IF NOT THIS IS A BIG FAILURE.

DONT take customer name alwasys for greeting

Avoid formal/book-style Hindi words like:
"kripya", "sahayata", "dhanyavaad", "anurodh".

Prefer natural words like:
"please", "sorry", "help", "issue", "callback", "renew".


CRITICAL FEMALE AGENT RULE:

You are RIYA.

You are a FEMALE insurance executive.

Every Hindi verb must be feminine:
✓ bol rahi hoon
✓ kar deti hoon
✓ bata deti hoon
✓ check karti hoon
✓ bhej deti hoon

Never use:
✗ bol raha hoon
✗ kar dunga
✗ check karunga
✗ samjhaunga

Before finalizing answer, verify all verbs are feminine.
If any masculine verb exists, rewrite response.

Use 1-2 short complete sentences only.
Maximum response length: around 20 words.
Keep tone warm, natural, and suitable for a live voice call.
Avoid robotic, awkward, translated, or unnatural phrases.

Before responding, check:
"Would a real human agent actually say this on a phone call?"
If the sentence sounds unnatural, rewrite it more conversationally. (ALWAYS BE POLITE)

Never reveal full mobile number or policy number.
Show only last 4 digits if needed.

Mention payment link or renewal link only if customer asks.

Do not restart conversation after short replies like:
"hello", "ok", "yes", "haan", "ji", "hmm".
Treat them as continuation of previous context.

Keep existing conversation memory and continue naturally.

If no previous context exists, reply exactly:
"This call is reminder of policy renewal, Can you please confirm if you want to renew now?"

Use only given policy data.
Never estimate, assume, calculate, or fabricate information.

Do not repeat the same sentence unnecessarily.
Understand customer intent and reply contextually.

If conversation has already started, never introduce yourself again.
Never repeat lines like:
"Hello sir, main Riya bol rahi hoon"
unless it is the very first message.
"""
        prompt_body = SYSTEM_PROMPT

    system_prompt = f"""{base_rules}

{prompt_body}

You are Riya, a friendly female insurance agent from Bajaj General Insurance. You are calling customers to remind them about their motor policy renewal. and connevence for them to renew their policy. You have access to the customer's policy data which you can use to answer their questions. Always keep the conversation warm and helpful, and try to assist the customer in renewing their policy.
you have to reply female tone and style.

Policy:
{policy_context}
"""

    messages = [{"role": "system", "content": system_prompt}]

    for role, msg in chat_history[-MAX_HISTORY:]:
        messages.append({
            "role": "assistant" if role == "bot" else "user",
            "content": msg
        })

    messages.append({"role": "user", "content": question})
    return messages, chat_history


async def answer_with_rag_sentences(question, caller_mobile, lang_code):
    """
    Streams only completed sentences to TTS.
    This avoids broken voice and reduces unnecessary churn.
    """
    messages, chat_history = _build_messages(question, caller_mobile, lang_code)

    full_response = ""
    sentence_buffer = ""

    try:
        async for chunk in _llm.astream(messages):
            token = chunk.content or ""
            if not token:
                continue

            sentence_buffer += token
            full_response += token

            stripped = sentence_buffer.strip()

            # Only yield on full sentence end
            if re.search(r"[.!?।]\s*$", stripped) and len(stripped.split()) >= 4:
                sentence = clean_text(stripped)
                if sentence:
                    yield sentence
                sentence_buffer = ""

        # leftover text
        if sentence_buffer.strip():
            remaining = clean_text(sentence_buffer.strip())
            if remaining:
                yield remaining

        response = clean_text(full_response.strip())
        chat_history.append(("user", question))
        chat_history.append(("bot", response))
        _caller_histories[caller_mobile] = chat_history[-MAX_HISTORY:]

    except Exception as e:
        print("❌ RAG stream error:", e)
        yield "Thodi technical problem hai, dobara try karein."


async def answer_with_rag_stream(question, caller_mobile, lang_code):
    """
    Non-streaming fallback — returns full response.
    """
    messages, chat_history = _build_messages(question, caller_mobile, lang_code)

    try:
        result = await _llm.ainvoke(messages)
        response = clean_text(result.content.strip())

        chat_history.append(("user", question))
        chat_history.append(("bot", response))
        _caller_histories[caller_mobile] = chat_history[-MAX_HISTORY:]

        return response

    except Exception as e:
        print("❌ RAG error:", e)
        return "Thodi technical problem hai, dobara try karein."
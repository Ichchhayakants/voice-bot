def detect_intent(text: str):
    t = text.lower()

    if any(w in t for w in ["haan", "हाँ", "yes", "ji haan"]):
        return "YES"
    if any(w in t for w in ["nahi", "नहीं", "no"]):
        return "NO"

    return "QUERY"

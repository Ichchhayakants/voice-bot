import base64
import json
import audioop
import asyncio
import time
import re
import azure.cognitiveservices.speech as speechsdk
from app.config.settings import AZURE_SPEECH_KEY, AZURE_REGION

# ✅ Global synthesizer — reuse
_speech_config = speechsdk.SpeechConfig(
    subscription=AZURE_SPEECH_KEY,
    region=AZURE_REGION
)
_speech_config.set_speech_synthesis_output_format(
    speechsdk.SpeechSynthesisOutputFormat.Raw16Khz16BitMonoPcm
)
_synthesizer = speechsdk.SpeechSynthesizer(
    speech_config=_speech_config,
    audio_config=None
)

def _build_ssml(text: str) -> str:
    return f"""<speak version='1.0' xml:lang='hi-IN'>
  <voice name='hi-IN-SwaraNeural'>
    <prosody rate='+35%' pitch='+5%'>
      {text}
    </prosody>
  </voice>
</speak>"""

async def _synthesize(text: str) -> bytes | None:
    try:
        ssml = _build_ssml(text)
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            None,
            lambda: _synthesizer.speak_ssml_async(ssml).get()
        )
        if result.reason != speechsdk.ResultReason.SynthesizingAudioCompleted:
            print(f"❌ Azure TTS failed: {result.reason}")
            return None
        return result.audio_data
    except Exception as e:
        print(f"❌ Synthesize error: {e}")
        return None


async def send_clear_audio(plivo_ws, stream_id=None):
    if not stream_id:
        return
    try:
        await plivo_ws.send_text(json.dumps({
            "event": "clearAudio",
            "streamId": stream_id
        }))
        print("🧹 clearAudio sent")
    except Exception as e:
        print(f"⚠️ clearAudio failed: {e}")


async def _send_audio(pcm_16k: bytes, plivo_ws, stop_event=None,
                      stream_id=None, playback_state=None) -> int:
    """Send audio to Plivo. Returns chunk count."""
    try:
        pcm_8k, _ = audioop.ratecv(pcm_16k, 2, 1, 16000, 8000, None)
        ulaw_audio = audioop.lin2ulaw(pcm_8k, 2)
        chunk_size = 320
        chunk_count = 0
        t0 = time.time()

        for i in range(0, len(ulaw_audio), chunk_size):
            if stop_event and stop_event.is_set():
                print("🛑 Barge-in during TTS send")
                await send_clear_audio(plivo_ws, stream_id)
                return chunk_count

            chunk = ulaw_audio[i:i + chunk_size]
            payload = base64.b64encode(chunk).decode()
            try:
                await plivo_ws.send_text(json.dumps({
                    "event": "playAudio",
                    "media": {
                        "contentType": "audio/x-mulaw",
                        "sampleRate": 8000,
                        "payload": payload
                    }
                }))
            except Exception:
                print("⚠️ WebSocket closed — TTS stop")
                return chunk_count

            chunk_count += 1
            if chunk_count == 1:
                print(f"⚡ First audio chunk in {time.time()-t0:.2f}s")
            if chunk_count % 10 == 0:
                await asyncio.sleep(0)

        return chunk_count
    except Exception as e:
        print(f"❌ Send error: {e}")
        return 0


async def stream_tts_to_plivo(text: str, plivo_ws, stop_event=None,
                               stream_id=None, playback_state=None):
    if not text.strip():
        return

    print(f"🔊 TTS: {text[:60]}")

    if stop_event and stop_event.is_set():
        await send_clear_audio(plivo_ws, stream_id)
        return

    t0 = time.time()
    total_chunks = 0

    sentences = re.split(r'(?<=[.!?,।])\s+', text.strip())
    sentences = [s.strip() for s in sentences if s.strip()]
    if not sentences:
        sentences = [text]

    if len(sentences) == 1:
        pcm = await _synthesize(sentences[0])
        if pcm:
            total_chunks = await _send_audio(pcm, plivo_ws, stop_event, stream_id, playback_state)
    else:
        first_task = asyncio.create_task(_synthesize(sentences[0]))
        rest_tasks = [asyncio.create_task(_synthesize(s)) for s in sentences[1:]]

        first_pcm = await first_task
        if first_pcm:
            total_chunks += await _send_audio(first_pcm, plivo_ws, stop_event, stream_id, playback_state)

        for task in rest_tasks:
            if stop_event and stop_event.is_set():
                break
            pcm = await task
            if pcm:
                total_chunks += await _send_audio(pcm, plivo_ws, stop_event, stream_id, playback_state)

    if playback_state is not None and total_chunks > 0:
        now = time.time()
        secs = total_chunks * 0.04
        if playback_state["until"] > now:
            playback_state["until"] += secs
        else:
            playback_state["until"] = now + secs

    print(f"✅ Sent ({total_chunks} chunks, {time.time()-t0:.2f}s)")
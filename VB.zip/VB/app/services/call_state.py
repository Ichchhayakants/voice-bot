class CallState:
    def __init__(self):
        self.is_speaking = False   # TTS running
        self.interrupted = False   # user interrupted
        self.stop_audio = False    # stop audio streaming
        self.plivo_ws = None       # websocket reference
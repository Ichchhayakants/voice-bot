from langchain_groq import ChatGroq
from app.config.settings import GROQ_API_KEY
from app.services.policy_data import get_policy_by_mobile
from app.services.System_prompt_english import SYSTEM_PROMPT
import re
from num2words import num2words


_llm = ChatGroq(
    api_key=GROQ_API_KEY,
    model="llama-3.1-8b-instant",
    max_tokens=150,
    temperature=0.6
)

_caller_histories = {}
_caller_policy_cache = {}

MAX_HISTORY = 3


def last4(value):
    value = str(value)
    return value[-4:] if len(value) >= 4 else value


def normalize_numbers(text: str) -> str:
    def replace_last4(match):
        digits = match.group(1)
        spoken = " ".join(num2words(int(d)) for d in digits)
        return f"last 4 digits {spoken}"

    text = re.sub(
        r"last 4 digits.*?(\d{4})",
        replace_last4,
        text,
        flags=re.IGNORECASE
    )

    def replace_id_number(match):
        digits = match.group(2)
        spoken = " ".join(num2words(int(d)) for d in digits)
        return f"{match.group(1)}{spoken}"

    text = re.sub(
        r"((?:registered\s+)?(?:mobile|phone|policy|number|no\.?|ID)\s*"
        r"(?:number|no\.?)?\s*[:,.\-]?\s*"
        r"(?:(?:is|ending\s+in|ends\s+in|ending\s+with|ends\s+with)\s*)?)"
        r"(\d{3,})",
        replace_id_number,
        text,
        flags=re.IGNORECASE,
    )

    def replace_number(match):
        num_str = match.group(0).replace(",", "")
        try:
            return num2words(int(num_str), lang="en_IN")
        except Exception:
            return match.group(0)

    text = re.sub(r"\d[\d,]+", replace_number, text)

    def replace_single(match):
        return num2words(int(match.group(0)))

    text = re.sub(r"\b\d\b", replace_single, text)
    text = re.sub(r"\s+", " ", text).strip()

    return text


def clean_text(text: str) -> str:
    text = re.sub(r"\s+", " ", text).strip()

    # Remove Hindi/Hinglish leakage if model accidentally produces it
    forbidden_words = [
        "namaste", "ji", "haan", "nahi", "kya", "aap", "main",
        "kripya", "dhanyavaad", "theek hai", "achha", "boliye",
        "renew karna", "policy renew karna"
    ]

    for word in forbidden_words:
        text = re.sub(rf"\b{re.escape(word)}\b", "", text, flags=re.IGNORECASE)

    # Remove Devanagari characters if any accidentally appear
    text = re.sub(r"[\u0900-\u097F]+", "", text)

    text = re.sub(r"\s+", " ", text).strip()

    if any(ch.isdigit() for ch in text):
        text = normalize_numbers(text)
        text = re.sub(r"\s+", " ", text).strip()

    return text


def _get_cached_policy_context(caller_mobile):
    if caller_mobile in _caller_policy_cache:
        return _caller_policy_cache[caller_mobile]

    policy = get_policy_by_mobile(caller_mobile)

    if not policy:
        _caller_policy_cache[caller_mobile] = "No policy data."
        return "No policy data."

    masked_mobile = " ".join(num2words(int(d)) for d in last4(caller_mobile))
    masked_policy = " ".join(
        num2words(int(d)) for d in last4(policy.get("policy_number"))
    )

    ctx = (
        f"Name: {policy.get('name')}\n"
        f"PolicyType: {policy.get('policy_type')}\n"
        f"Expiry: {policy.get('expiry')}\n"
        f"Premium: {policy.get('Total_payable_amount')}\n"
        f"SumInsured: {policy.get('sum_prem')}\n"
        f"MobileLast4: {masked_mobile}\n"
        f"PolicyLast4: {masked_policy}\n"
        f"Last year Premium: Fifteen thousand rupees\n"
        f"Family members covered: You, wife Sunita, two kids Rahul and Riya"
    )

    _caller_policy_cache[caller_mobile] = ctx
    return ctx


def _build_messages(question, caller_mobile, lang_code="en-IN"):
    if caller_mobile not in _caller_histories:
        _caller_histories[caller_mobile] = []

    chat_history = _caller_histories[caller_mobile]
    policy_context = _get_cached_policy_context(caller_mobile)

    english_rules = """
STRICT LANGUAGE RULE:
Reply ONLY in English. (CRITICAL)
Do not use Hindi.
Do not use Hinglish.
Do not use Devanagari.
Do not use "ji".
Even if the customer speaks Hindi or Hinglish, reply only in English.

VOICE CALL STYLE:
Use 1 to 2 short complete sentences.
Maximum 25 words.
Sound warm, natural, and professional.
Address the customer as "sir" only when needed.
Do not sound robotic.

CONVERSATION RULES:
Do not restart after hello, hi, ok, yes, no, hmm, or filler words.
If the conversation has already started, do not introduce yourself again.
Never say "Hello sir, this is Rahul" again after the first greeting.
Never repeat the same sentence.
Do not fall into a loop.
Understand the customer's latest statement and reply contextually.
Do not ask unnecessary questions.

POLICY RULES:
Use only the given policy data.
Never assume, estimate, or fabricate policy details.
Never reveal full mobile number or full policy number.
If asked for mobile or policy number, use only the last 4 digits digit by digit.

RENEWAL RULES:
If customer agrees, guide them toward renewal.
If customer asks for premium, use the given premium only.
If customer says they will renew later, briefly explain continuity risk and offer callback.
If customer refuses, acknowledge politely and give one short benefit reminder.
"""

    system_prompt = f"""{english_rules}

{SYSTEM_PROMPT}

You are Riya, a friendly female insurance agent from Bajaj General Insurance. You are calling customers to remind them about their motor policy renewal. and connevence for them to renew their policy. You have access to the customer's policy data which you can use to answer their questions. Always keep the conversation warm and helpful, and try to assist the customer in renewing their policy.
you have to reply female tone and style.

Policy:
{policy_context}
"""

    messages = [{"role": "system", "content": system_prompt}]

    for role, msg in chat_history[-MAX_HISTORY:]:
        messages.append({
            "role": "assistant" if role == "bot" else "user",
            "content": msg
        })

    messages.append({"role": "user", "content": question})

    return messages, chat_history


def is_repetitive(new_text, last_text):
    if not new_text or not last_text:
        return False

    new = new_text.lower().strip()
    old = last_text.lower().strip()

    return new == old or new in old or old in new


def get_last_bot_message(chat_history):
    for role, msg in reversed(chat_history):
        if role == "bot":
            return msg
    return ""


async def answer_with_rag_sentences(question, caller_mobile, lang_code="en-IN"):
    messages, chat_history = _build_messages(question, caller_mobile, "en-IN")

    full_response = ""
    sentence_buffer = ""
    last_sentence = ""
    last_bot_msg = get_last_bot_message(chat_history)

    try:
        async for chunk in _llm.astream(messages):
            token = chunk.content or ""

            if not token:
                continue

            sentence_buffer += token
            full_response += token

            stripped = sentence_buffer.strip()

            if re.search(r"[.!?]\s*$", stripped) and len(stripped.split()) >= 4:
                sentence = clean_text(stripped)

                if not sentence:
                    sentence_buffer = ""
                    continue

                if is_repetitive(sentence, last_sentence):
                    sentence_buffer = ""
                    continue

                if is_repetitive(sentence, last_bot_msg):
                    sentence_buffer = ""
                    continue

                last_sentence = sentence
                yield sentence
                sentence_buffer = ""

        if sentence_buffer.strip():
            remaining = clean_text(sentence_buffer.strip())

            if remaining:
                if not is_repetitive(remaining, last_sentence) and not is_repetitive(remaining, last_bot_msg):
                    yield remaining

        response = clean_text(full_response.strip())

        chat_history.append(("user", question))
        chat_history.append(("bot", response))
        _caller_histories[caller_mobile] = chat_history[-MAX_HISTORY:]

    except Exception as e:
        print("❌ RAG stream error:", e)
        yield "There is a technical issue. Please try again later."


async def answer_with_rag_stream(question, caller_mobile, lang_code="en-IN"):
    messages, chat_history = _build_messages(question, caller_mobile, "en-IN")

    try:
        result = await _llm.ainvoke(messages)
        response = clean_text(result.content.strip())

        last_bot_msg = get_last_bot_message(chat_history)

        if is_repetitive(response, last_bot_msg):
            response = "Yes sir, I can help you with that."

        chat_history.append(("user", question))
        chat_history.append(("bot", response))
        _caller_histories[caller_mobile] = chat_history[-MAX_HISTORY:]

        return response

    except Exception as e:
        print("❌ RAG error:", e)
        return "There is a technical issue. Please try again later."
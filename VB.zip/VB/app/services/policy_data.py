import pandas as pd
from datetime import datetime, timedelta
from app.config.settings import POLICY_EXCEL_PATH

policy_df = pd.read_excel(POLICY_EXCEL_PATH)
policy_df.columns = policy_df.columns.str.strip()

# def normalize_excel_date(value):
#     if pd.isna(value):
#         return None

#     value = str(value).strip()

#     # Case 1: Excel serial number
#     if value.isdigit():
#         excel_epoch = datetime(1899, 12, 30)
#         return (excel_epoch + timedelta(days=int(value))).strftime("%d-%m-%Y")

#     # Case 2: Datetime string
#     for fmt in (
#         "%Y-%m-%d %H:%M:%S",
#         "%d-%m-%Y",
#         "%d/%m/%Y",
#         "%Y-%m-%d"
#     ):
#         try:
#             return datetime.strptime(value, fmt).strftime("%d-%m-%Y")
#         except:
#             pass

#     return value  # fallback

# policy_df["R RID (To be correct)"] = policy_df["R RID (To be correct)"].apply(normalize_excel_date)

def get_policy_by_mobile(mobile):
    row = policy_df[policy_df["Mobile No"] == mobile]
    if row.empty:
        return None

    row = row.iloc[0]
    return {
        "mobile no": mobile,
        "name": row.get("First Name"),
        "policy_number": row.get("Policy Number"),
        "policy_type": row.get("Product Type (LOB)"),
        "expiry": str(row.get("R RID (To be correct)")),
        "sum_prem"   : row.get("R TBR Sum Insured"),
        "Total_payable_amount"   : row.get("Total payable amount"),
        "policy_number": row.get("Policy Number")
    }



MONTHS_HI = [
    "जनवरी","फ़रवरी","मार्च","अप्रैल","मई","जून",
    "जुलाई","अगस्त","सितंबर","अक्टूबर","नवंबर","दिसंबर"
]

MONTHS_EN = [
    "January","February","March","April","May","June",
    "July","August","September","October","November","December"
]


def normalize_date_for_speech(date_str, language="hi"):
    """
    Converts DD-MM-YYYY to spoken-friendly date
    language: 'hi' or 'en'
    """
    try:
        d, m, y = map(int, date_str.split('-'))

        if language.lower() == "en":
            return f"{d} {MONTHS_EN[m-1]} {y}"
        else:  # default Hindi
            return f"{d} {MONTHS_HI[m-1]} {y}"

    except Exception:
        return date_str
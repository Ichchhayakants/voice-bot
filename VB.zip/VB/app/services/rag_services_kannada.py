from langchain_groq import ChatGroq
from app.config.settings import GROQ_API_KEY
from app.services.policy_data import get_policy_by_mobile
from app.services.System_prompt_tamil import SYSTEM_PROMPT
import re

_llm = ChatGroq(
    api_key=GROQ_API_KEY,
    model="llama-3.1-8b-instant",
    max_tokens=150,
    temperature=0.6
)

_caller_histories = {}
_caller_policy_cache = {}

MAX_HISTORY = 3


def last4(value):
    value = str(value)
    return value[-4:] if len(value) >= 4 else value


def speak_digits_tamil(digits: str) -> str:
    tamil_digits = {
        "0": "பூஜ்யம்",
        "1": "ஒன்று",
        "2": "இரண்டு",
        "3": "மூன்று",
        "4": "நான்கு",
        "5": "ஐந்து",
        "6": "ஆறு",
        "7": "ஏழு",
        "8": "எட்டு",
        "9": "ஒன்பது",
    }
    return " ".join(tamil_digits.get(d, d) for d in str(digits))


def speak_digits_english(digits: str) -> str:
    english_digits = {
        "0": "zero",
        "1": "one",
        "2": "two",
        "3": "three",
        "4": "four",
        "5": "five",
        "6": "six",
        "7": "seven",
        "8": "eight",
        "9": "nine",
    }
    return " ".join(english_digits.get(d, d) for d in str(digits))


def clean_text(text: str, lang_code="ta-IN") -> str:
    text = re.sub(r"\s+", " ", text).strip()

    if lang_code == "en-IN":
        text = text.replace("₹", " rupees ")
        text = text.replace("INR", "rupees")
    else:
        text = text.replace("₹", "ரூபாய் ")
        text = text.replace("INR", "ரூபாய்")

    return text.strip()


def _get_cached_policy_context(caller_mobile):
    if caller_mobile in _caller_policy_cache:
        return _caller_policy_cache[caller_mobile]

    policy = get_policy_by_mobile(caller_mobile)
    if not policy:
        _caller_policy_cache[caller_mobile] = "No policy data."
        return "No policy data."

    mobile_last4 = last4(caller_mobile)
    policy_last4 = last4(policy.get("policy_number"))

    ctx = (
        f"Name: {policy.get('name')}\n"
        f"PolicyType: {policy.get('policy_type')}\n"
        f"Expiry: {policy.get('expiry')}\n"
        f"Premium: {policy.get('Total_payable_amount')}\n"
        f"SumInsured: {policy.get('sum_prem')}\n"
        f"MobileLast4Tamil: {speak_digits_tamil(mobile_last4)}\n"
        f"PolicyLast4Tamil: {speak_digits_tamil(policy_last4)}\n"
        f"MobileLast4English: {speak_digits_english(mobile_last4)}\n"
        f"PolicyLast4English: {speak_digits_english(policy_last4)}\n"
        f"Last year Premium: Fifteen thousand rupees\n"
        f"Family members covered: You, wife Sunita, two kids Rahul and Riya"
        f"Previous year NCB: Twenty percent \n"
        f"Current year NCB: Fifty percent \n"

    )

    _caller_policy_cache[caller_mobile] = ctx
    return ctx




def _build_messages(question, caller_mobile, lang_code):
    if caller_mobile not in _caller_histories:
        _caller_histories[caller_mobile] = []

    chat_history = _caller_histories[caller_mobile]
    policy_context = _get_cached_policy_context(caller_mobile)

    if lang_code == "en-IN":
        language_rules = """
CRITICAL LANGUAGE OVERRIDE:
The customer is speaking English.
Reply ONLY in English.
Do NOT use Tamil words.
Do NOT use Tamil script.
Do NOT translate into Tamil.
Ignore any Tamil-only examples inside the main prompt.
Use English examples only.
"""
    else:
        language_rules = """
CRITICAL LANGUAGE OVERRIDE:
The customer is speaking Tamil.
Reply ONLY in Tamil script.
Do NOT use English sentences.
Use Tamil examples only.
"""

    system_prompt = f"""
{language_rules}

{SYSTEM_PROMPT}

{language_rules}

You are Rahul, a friendly male insurance agent from General Insurance.

Policy:
{policy_context}
"""

    messages = [{"role": "system", "content": system_prompt}]

    for role, msg in chat_history[-MAX_HISTORY:]:
        messages.append({
            "role": "assistant" if role == "bot" else "user",
            "content": msg
        })

    messages.append({"role": "user", "content": question})
    return messages, chat_history


async def answer_with_rag_sentences(question, caller_mobile, lang_code):
    messages, chat_history = _build_messages(question, caller_mobile, lang_code)

    full_response = ""
    sentence_buffer = ""

    try:
        async for chunk in _llm.astream(messages):
            token = chunk.content or ""
            if not token:
                continue

            sentence_buffer += token
            full_response += token

            stripped = sentence_buffer.strip()

            if re.search(r"[.!?।]\s*$", stripped) and len(stripped.split()) >= 3:
                sentence = clean_text(stripped, lang_code)
                if sentence:
                    yield sentence
                sentence_buffer = ""

        if sentence_buffer.strip():
            remaining = clean_text(sentence_buffer.strip(), lang_code)
            if remaining:
                yield remaining

        response = clean_text(full_response.strip(), lang_code)

        chat_history.append(("user", question))
        chat_history.append(("bot", response))
        _caller_histories[caller_mobile] = chat_history[-MAX_HISTORY:]

    except Exception as e:
        print("❌ RAG stream error:", e)

        if lang_code == "en-IN":
            yield "There is a small technical issue. Could you please repeat that?"
        else:
            yield "சிறிய தொழில்நுட்ப பிரச்சனை உள்ளது. தயவுசெய்து மீண்டும் சொல்லுங்கள்."


async def answer_with_rag_stream(question, caller_mobile, lang_code):
    messages, chat_history = _build_messages(question, caller_mobile, lang_code)

    try:
        result = await _llm.ainvoke(messages)
        response = clean_text(result.content.strip(), lang_code)

        chat_history.append(("user", question))
        chat_history.append(("bot", response))
        _caller_histories[caller_mobile] = chat_history[-MAX_HISTORY:]

        return response

    except Exception as e:
        print("❌ RAG error:", e)

        if lang_code == "en-IN":
            return "There is a small technical issue. Could you please repeat that?"
        return "சிறிய தொழில்நுட்ப பிரச்சனை உள்ளது. தயவுசெய்து மீண்டும் சொல்லுங்கள்."
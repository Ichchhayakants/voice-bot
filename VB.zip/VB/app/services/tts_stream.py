import json
import base64
import asyncio
import re
import io
import audioop
import httpx
from pydub import AudioSegment
from app.config.settings import API_KEY_ele_lab, VOICE_ID


ELEVEN_URL = f"https://api.elevenlabs.io/v1/text-to-speech/{VOICE_ID}"
HEADERS = {
    "xi-api-key": API_KEY_ele_lab,
    "Content-Type": "application/json"
}

async def stream_tts_to_plivo(text: str, plivo_ws):
    if not text.strip():
        return

    print(f"🔊 TTS: {text[:60]}")

    sentences = re.split(r'(?<=[.!?।])\s+', text.strip())
    sentences = [s.strip() for s in sentences if s.strip()]
    if not sentences:
        sentences = [text]

    if len(sentences) == 1:
        await _send_sentence(sentences[0], plivo_ws)
        return

    # ✅ Pehla sentence jaldi bhejo, baaki parallel synthesize karo
    first_task = asyncio.create_task(_synthesize(sentences[0]))
    rest_tasks = [asyncio.create_task(_synthesize(s)) for s in sentences[1:]]

    first_audio = await first_task
    if first_audio:
        ok = await _stream_audio(first_audio, plivo_ws)
        if not ok:
            return

    for task in rest_tasks:
        audio = await task
        if audio:
            ok = await _stream_audio(audio, plivo_ws)
            if not ok:
                return

async def _synthesize(text: str) -> bytes | None:
    payload = {
        "text": text,
        # "model_id": "eleven_multilingual_v2",
        "model_id": "eleven_turbo_v2_5",
        "voice_settings": {
            "stability": 0.8,
            "similarity_boost": 0.85,
            "style": 0.2,
            "use_speaker_boost": True,
            "speed": 1.1
        }
    }
    try:
        async with httpx.AsyncClient(timeout=8) as client:
            response = await client.post(
                ELEVEN_URL,
                headers=HEADERS,
                json=payload
            )
        if response.status_code != 200:
            print("❌ ElevenLabs Error:", response.status_code)
            return None
        return response.content
    except Exception as e:
        print("❌ Synthesize Error:", str(e))
        return None

async def _stream_audio(mp3_bytes: bytes, plivo_ws) -> bool:
    try:
        audio = AudioSegment.from_file(io.BytesIO(mp3_bytes), format="mp3")
        audio = audio.set_channels(1).set_frame_rate(8000).set_sample_width(2)
        ulaw_audio = audioop.lin2ulaw(audio.raw_data, 2)

        chunk_size = 320
        for i in range(0, len(ulaw_audio), chunk_size):
            chunk = ulaw_audio[i:i + chunk_size]
            encoded = base64.b64encode(chunk).decode("utf-8")
            try:
                await plivo_ws.send_text(json.dumps({
                    "event": "playAudio",
                    "media": {
                        "contentType": "audio/x-mulaw",
                        "sampleRate": 8000,
                        "payload": encoded
                    }
                }))
            except Exception:
                print("⚠️ WebSocket closed — TTS stop")
                return False

        print("✅ Sentence sent")
        return True

    except Exception as e:
        print("❌ Stream Error:", str(e))
        return False

async def _send_sentence(text: str, plivo_ws):
    audio = await _synthesize(text)
    if audio:
        await _stream_audio(audio, plivo_ws)
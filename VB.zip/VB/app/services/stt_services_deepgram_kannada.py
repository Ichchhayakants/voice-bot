import asyncio
import json
import time
import inspect
import audioop
import re
import websockets
from app.config.settings import Deepgram_key

# Optional denoise
try:
    import numpy as np
    import noisereduce as nr
    DENOISE_AVAILABLE = True
except Exception:
    DENOISE_AVAILABLE = False


DEEPGRAM_API_KEY = Deepgram_key
DEEPGRAM_WS_URL = "wss://api.deepgram.com/v1/listen"

_ws_sig = inspect.signature(websockets.connect)
_HEADER_KWARG = "additional_headers" if "additional_headers" in _ws_sig.parameters else "extra_headers"


# --------------------------------------------------
# LANGUAGE DETECTION: Tamil + English
# --------------------------------------------------
_KANNADA_RE = re.compile(r"[\u0C80-\u0CFF]")

ENGLISH_HINTS = {
    "hello", "hi", "yes", "no", "okay", "ok", "please",
    "renew", "policy", "insurance", "tell", "what", "why",
    "english", "speak", "can", "you", "premium", "amount",
    "send", "link", "call", "later", "tomorrow"
}

KANNADA_ROMAN_HINTS = {
    "namaskara",
    "haudu",
    "illa",
    "sari",
    "paravagilla",
    "beku",
    "beda",
    "heli",
    "maatadi",
    "matadi",
    "enu",
    "yake",
    "yavaga",
    "naale",
    "ivattu",
    "nanu",
    "nanage",
    "nimma",
    "kannada",
    "policy",
    "renewal",
    "insurance"
}


LANGUAGE_LOCK = None   # global variable


def _detect_lang(text: str) -> str:
    global LANGUAGE_LOCK

    if LANGUAGE_LOCK == "en-IN":
        return "en-IN"

    t = text.strip().lower()

    if not t:
        return "kn-IN"

    if _KANNADA_RE.search(t):
        return "kn-IN"

    words = set(re.findall(r"[a-zA-Z']+", t))

    if words & KANNADA_ROMAN_HINTS:
        return "kn-IN"

    if len(words) >= 2:
        LANGUAGE_LOCK = "en-IN"
        return "en-IN"

    if len(words) == 1:
        word = list(words)[0]
        if word in ENGLISH_HINTS:
            LANGUAGE_LOCK = "en-IN"
            return "en-IN"

    return "kn-IN"


class DeepgramSTTStream:
    def __init__(self):
        self.detected_lang = "kn-IN"
        self._callback = None
        self._loop = None
        self._ws = None
        self._connected = False
        self._closing = False

        self._last_transcript = ""
        self._last_sent_time = 0.0

        self._receive_task = None
        self._keepalive_task = None
        self._send_task = None
        self._audio_queue = None

        # Noise gate state
        self._speech_count = 0
        self._frame_index = 0

        # Tune values
        self.ENABLE_DENOISE = False
        self.DENOISE_EVERY_N_FRAMES = 2

        self.MIN_RMS = 80
        self.MAX_STATIC_RMS = 8000
        self.MAX_STATIC_ZCR = 250
        self.MIN_ZCR = 1
        self.MAX_ZCR = 300
        self.REQUIRED_SPEECH_FRAMES = 1

    def set_callback(self, callback, loop):
        self._callback = callback
        self._loop = loop
        self._audio_queue = asyncio.Queue(maxsize=200)
        asyncio.ensure_future(self._connect())

    async def _connect(self):
        if self._closing:
            return

        params = (
            "model=nova-3"
            "&language=multi"
            "&encoding=linear16"
            "&sample_rate=8000"
            "&channels=1"
            "&punctuate=false"
            "&smart_format=false"
            "&endpointing=300"
            "&interim_results=true"
            "&utterance_end_ms=1000"
        )

        url = f"{DEEPGRAM_WS_URL}?{params}"

        print("🔗 Deepgram URL:", url)
        print("🔑 DG KEY START:", DEEPGRAM_API_KEY[:6])

        headers = {
            _HEADER_KWARG: {
                "Authorization": f"Token {DEEPGRAM_API_KEY}"
            }
        }

        for attempt in range(2):
            try:
                self._ws = await websockets.connect(
                    url,
                    **headers,
                    ping_interval=20
                )

                self._connected = True

                self._receive_task = asyncio.ensure_future(self._receive_loop())
                self._keepalive_task = asyncio.ensure_future(self._keepalive_loop())
                self._send_task = asyncio.ensure_future(self._send_loop())

                suffix = " retry" if attempt > 0 else ""
                print(f"✅ Deepgram streaming connected{suffix}")
                return

            except Exception as e:
                print(f"❌ Deepgram connect error attempt {attempt + 1}: {e}")
                if attempt == 0:
                    await asyncio.sleep(1)

        print("❌ Deepgram connect failed after retries")

    async def _keepalive_loop(self):
        try:
            while self._connected and self._ws:
                await asyncio.sleep(8)
                if self._connected and self._ws:
                    await self._ws.send(json.dumps({"type": "KeepAlive"}))
        except Exception:
            pass

    async def _send_loop(self):
        while self._connected:
            try:
                chunk = await asyncio.wait_for(
                    self._audio_queue.get(),
                    timeout=1.0
                )

                if self._ws and self._connected:
                    await self._ws.send(chunk)

            except asyncio.TimeoutError:
                continue
            except Exception as e:
                print(f"❌ Deepgram send error: {e}")
                self._connected = False
                break

    async def _receive_loop(self):
        try:
            async for msg in self._ws:
                data = json.loads(msg)

                if data.get("type") != "Results":
                    continue

                is_final = data.get("is_final", False)

                transcript = (
                    data.get("channel", {})
                    .get("alternatives", [{}])[0]
                    .get("transcript", "")
                    .strip()
                )

                confidence = (
                    data.get("channel", {})
                    .get("alternatives", [{}])[0]
                    .get("confidence", 0.0)
                )

                if not is_final:
                    continue

                if not transcript or len(transcript) < 2:
                    continue

                if self._is_bad_transcript(transcript, confidence):
                    print(f"⏭️ Transcript skipped: '{transcript}' | conf={confidence}")
                    continue

                # ✅ MAIN FIX: detect language from transcript
                self.detected_lang = _detect_lang(transcript)

                now = time.time()

                if transcript != self._last_transcript or now - self._last_sent_time > 1.2:
                    self._last_transcript = transcript
                    self._last_sent_time = now

                    print(f"🎙️ STT [{self.detected_lang}]: '{transcript}' | conf={confidence}")

                    if self._callback:
                        await self._callback(transcript, self.detected_lang)
                else:
                    print(f"⏭️ Duplicate skipped: '{transcript}'")

        except websockets.exceptions.ConnectionClosed:
            print("📞 Deepgram WS closed")
        except Exception as e:
            print(f"❌ Deepgram receive error: {e}")
        finally:
            self._connected = False

            if not self._closing:
                print("🔄 Deepgram reconnecting...")
                await self._connect()

    def _denoise_pcm(self, pcm_chunk: bytes) -> bytes:
        return pcm_chunk

    def _is_probable_speech(self, pcm_chunk: bytes) -> bool:
        try:
            rms = audioop.rms(pcm_chunk, 2)
            zcr = audioop.cross(pcm_chunk, 2)
            print("RMS:", rms, "ZCR:", zcr)
        except Exception:
            return False

        if rms < self.MIN_RMS:
            self._speech_count = 0
            return False

        if rms > self.MAX_STATIC_RMS and zcr > self.MAX_STATIC_ZCR:
            self._speech_count = 0
            return False

        if zcr < self.MIN_ZCR:
            self._speech_count = 0
            return False

        if zcr > self.MAX_ZCR:
            self._speech_count = max(0, self._speech_count - 1)
            return False

        self._speech_count += 1
        return self._speech_count >= self.REQUIRED_SPEECH_FRAMES

    def _is_bad_transcript(self, text: str, confidence: float = 0.0) -> bool:
        t = text.lower().strip()

        if len(t) < 2:
            return True

        if confidence and confidence < 0.45:
            return True

        now = time.time()

        if t == self._last_transcript.lower().strip() and now - self._last_sent_time < 1.2:
            return True

        return False

    def push_audio(self, pcm_chunk: bytes):
        if not self._connected or not self._audio_queue:
            return

        if not pcm_chunk:
            return

        pcm_chunk = self._denoise_pcm(pcm_chunk)

        try:
            self._audio_queue.put_nowait(pcm_chunk)
        except asyncio.QueueFull:
            pass

    def close(self):
        self._closing = True
        self._connected = False

        if self._keepalive_task:
            self._keepalive_task.cancel()

        if self._send_task:
            self._send_task.cancel()

        if self._receive_task:
            self._receive_task.cancel()

        if self._ws:
            asyncio.ensure_future(self._close_ws())

    async def _close_ws(self):
        try:
            if self._ws:
                await self._ws.send(json.dumps({"type": "CloseStream"}))
                await self._ws.close()
        except Exception:
            pass

    def get_text(self):
        return "", self.detected_lang


def create_stt_stream():
    return DeepgramSTTStream()
﻿from langchain_groq import ChatGroq


GROQ_API_KEY = "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"
def main():

    # Check API key
    if not GROQ_API_KEY:
        print("ERROR: GROQ_API_KEY is not configured.")
        return

    print("API key found.")
    print("Initializing Groq LLM...")

    # Initialize LLM
    llm = ChatGroq(
        api_key=GROQ_API_KEY,
        model="openai/gpt-oss-20b",
        max_tokens=130,
        temperature=0.2
    )

    print("LLM initialized successfully.")
    print("Sending test request...\n")

    try:
        response = llm.invoke(
            "Hello! Please introduce yourself in one short sentence."
        )

        print("LLM Response:")
        print(response.content)

        print("\n-------------------------")
        print("LLM is working successfully!")
        print("-------------------------")

    except Exception as e:
        print("LLM request failed!")
        print("Error:", str(e))


if __name__ == "__main__":
    main()


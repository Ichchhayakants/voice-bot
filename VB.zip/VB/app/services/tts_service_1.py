import json
import base64
import asyncio
import time
import httpx
from app.config.settings import API_KEY_ele_lab, VOICE_ID

STREAM_URL = f"https://api.elevenlabs.io/v1/text-to-speech/{VOICE_ID}/stream"
HEADERS = {
    "xi-api-key": API_KEY_ele_lab,
    "Content-Type": "application/json"
}

_tts_client = None

async def _get_tts_client():
    global _tts_client
    if _tts_client is None or _tts_client.is_closed:
        _tts_client = httpx.AsyncClient(
            timeout=httpx.Timeout(connect=5.0, read=30.0, write=5.0, pool=5.0)
        )
    return _tts_client

async def warmup_tts():
    """Pre-warm the ElevenLabs connection on startup."""
    try:
        client = await _get_tts_client()
        async with client.stream(
            "POST", STREAM_URL,
            headers=HEADERS,
            json={"text": ".", "model_id": "eleven_turbo_v2_5",
                  "voice_settings": {"stability": 0.8, "similarity_boost": 0.85}},
            params={"output_format": "ulaw_8000", "optimize_streaming_latency": "3"}
        ) as resp:
            async for _ in resp.aiter_bytes(640):
                break  # just establish connection
        print("✅ TTS warmed up")
    except Exception as e:
        print(f"⚠️ TTS warmup failed: {e}")

        
async def send_clear_audio(plivo_ws, stream_id=None):
    if not stream_id:
        return
    try:
        await plivo_ws.send_text(json.dumps({
            "event": "clearAudio",
            "streamId": stream_id
        }))
        print("🧹 clearAudio sent")
    except Exception as e:
        print(f"⚠️ clearAudio failed: {e}")


async def stream_tts_to_plivo(text, plivo_ws, stop_event=None,
                               stream_id=None, playback_state=None):
    if not text.strip():
        return

    print(f"🔊 TTS: {text[:60]}")

    if stop_event and stop_event.is_set():
        await send_clear_audio(plivo_ws, stream_id)
        return

    payload = {
        "text": text,
        "model_id": "eleven_turbo_v2_5",
        "voice_settings": {
            "stability": 0.8,
            "similarity_boost": 0.85,
            "style": 0.2,
            "use_speaker_boost": True,
            "speed": 0.95
        }
    }

    max_retries = 3
    for attempt in range(max_retries):
        try:
            client = await _get_tts_client()
            chunk_count = 0
            ulaw_buffer = bytearray()
            t0 = time.time()

            async with client.stream(
                "POST", STREAM_URL,
                headers=HEADERS,
                json=payload,
                params={"output_format": "ulaw_8000","optimize_streaming_latency": "1"}
            ) as response:
                if response.status_code == 429:
                    body = await response.aread()
                    wait = 0.5 * (attempt + 1)
                    print(f"⚠️ ElevenLabs 429 — retry {attempt+1}/{max_retries} in {wait}s")
                    await asyncio.sleep(wait)
                    continue

                if response.status_code != 200:
                    body = await response.aread()
                    print(f"❌ ElevenLabs: {response.status_code} {body[:200]}")
                    return

                async for data in response.aiter_bytes(640):
                    if stop_event and stop_event.is_set():
                        print("🛑 Barge-in during TTS stream")
                        await send_clear_audio(plivo_ws, stream_id)
                        return

                    ulaw_buffer.extend(data)

                    while len(ulaw_buffer) >= 320:
                        chunk = bytes(ulaw_buffer[:320])
                        ulaw_buffer = bytearray(ulaw_buffer[320:])
                        encoded = base64.b64encode(chunk).decode("utf-8")

                        try:
                            await plivo_ws.send_text(json.dumps({
                                "event": "playAudio",
                                "media": {
                                    "contentType": "audio/x-mulaw",
                                    "sampleRate": 8000,
                                    "payload": encoded
                                }
                            }))
                        except Exception:
                            print("⚠️ WebSocket closed")
                            return

                        chunk_count += 1
                        if chunk_count == 1:
                            print(f"⚡ First audio chunk in {time.time()-t0:.2f}s")
                        if chunk_count % 10 == 0:
                            await asyncio.sleep(0)

            # Send remaining buffer
            if ulaw_buffer and not (stop_event and stop_event.is_set()):
                encoded = base64.b64encode(bytes(ulaw_buffer)).decode("utf-8")
                try:
                    await plivo_ws.send_text(json.dumps({
                        "event": "playAudio",
                        "media": {
                            "contentType": "audio/x-mulaw",
                            "sampleRate": 8000,
                            "payload": encoded
                        }
                    }))
                    chunk_count += 1
                except Exception:
                    pass

            if playback_state is not None:
                now = time.time()
                secs = chunk_count * 0.04
                if playback_state["until"] > now:
                    playback_state["until"] += secs
                else:
                    playback_state["until"] = now + secs

            print(f"✅ Sent ({chunk_count} chunks, {time.time()-t0:.2f}s)")
            return  # Success — exit retry loop

        except asyncio.CancelledError:
            await send_clear_audio(plivo_ws, stream_id)
            raise
        except Exception as e:
            print(f"❌ TTS Error: {e}")
            return

    print("❌ ElevenLabs: all retries failed (429)")
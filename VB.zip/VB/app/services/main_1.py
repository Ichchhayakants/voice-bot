
import asyncio
import base64
import json
import time
import audioop
import httpx
from contextlib import asynccontextmanager
from fastapi import FastAPI, WebSocket, Request, WebSocketDisconnect
from fastapi.responses import Response
from fastapi.staticfiles import StaticFiles
from app.services.stt_services_deepgram import create_stt_stream
from app.services.rag_services_1 import answer_with_rag_sentences, answer_with_rag_stream
from app.services.tts_service_1 import stream_tts_to_plivo, send_clear_audio
# from app.services.tts_stream_azure import stream_tts_to_plivo, send_clear_audio
from app.services.policy_data import get_policy_by_mobile, normalize_date_for_speech, policy_df
from app.config.settings import Plivo_ID, Plivo_token, PUBLIC_URL
@asynccontextmanager
async def lifespan(app):
    from app.services.tts_service_1 import warmup_tts
    await warmup_tts()
    yield

app = FastAPI(lifespan=lifespan)
app.mount("/audio", StaticFiles(directory="app"), name="audio")

print("📊 Mobile No sample:", policy_df["Mobile No"].head(10).tolist())

PLIVO_AUTH_ID = Plivo_ID
PLIVO_AUTH_TOKEN = Plivo_token
BASE_URL = PUBLIC_URL

VOICEMAIL_KEYWORDS = [
    "forwarded to", "not available", "record your message",
    "after the beep", "please leave", "hang up",
    "voicemail", "message after tone"
]

def is_voicemail(text: str) -> bool:
    t = text.lower()
    return any(k in t for k in VOICEMAIL_KEYWORDS)

def to_hinglish(text: str) -> str:
    """Transliterate Devanagari text to Roman/Hinglish for keyword matching."""
    mapping = {
        'अ': 'a', 'आ': 'aa', 'इ': 'i', 'ई': 'ee', 'उ': 'u', 'ऊ': 'oo',
        'ए': 'e', 'ऐ': 'ai', 'ओ': 'o', 'औ': 'au', 'ऋ': 'ri',
        'ा': 'aa', 'ि': 'i', 'ी': 'ee', 'ु': 'u', 'ू': 'oo',
        'े': 'e', 'ै': 'ai', 'ो': 'o', 'ौ': 'au', 'ृ': 'ri',
        'क': 'ka', 'ख': 'kha', 'ग': 'ga', 'घ': 'gha', 'ङ': 'nga',
        'च': 'cha', 'छ': 'chha', 'ज': 'ja', 'झ': 'jha', 'ञ': 'nya',
        'ट': 'ta', 'ठ': 'tha', 'ड': 'da', 'ढ': 'dha', 'ण': 'na',
        'त': 'ta', 'थ': 'tha', 'द': 'da', 'ध': 'dha', 'न': 'na',
        'प': 'pa', 'फ': 'pha', 'ब': 'ba', 'भ': 'bha', 'म': 'ma',
        'य': 'ya', 'र': 'ra', 'ल': 'la', 'व': 'va', 'श': 'sha',
        'ष': 'sha', 'स': 'sa', 'ह': 'ha',
        'ं': 'n', 'ँ': 'n', 'ः': 'h', '्': '', 'ॉ': 'o',
        'ड़': 'da', 'ढ़': 'dha', 'ज़': 'za', 'फ़': 'fa',
        '़': '',
        'क़': 'qa', 'ख़': 'kha', 'ग़': 'ga',
    }

    result = []
    i = 0
    while i < len(text):
        if i + 1 < len(text) and text[i:i+2] in mapping:
            result.append(mapping[text[i:i+2]])
            i += 2
        elif text[i] in mapping:
            result.append(mapping[text[i]])
            i += 1
        else:
            result.append(text[i])
            i += 1

    return ''.join(result)

def get_caller_mobile(raw_number: str) -> int:
    raw = str(raw_number).strip().lstrip("+")
    excel_numbers = policy_df["Mobile No"].dropna().astype(str).tolist()
    if raw in excel_numbers:
        return int(raw)
    if raw.startswith("91") and raw[2:] in excel_numbers:
        return int(raw[2:])
    if ("91" + raw) in excel_numbers:
        return int("91" + raw)
    print(f"⚠️ No Excel match for: {raw}")
    return int(raw) if str(raw).isdigit() else 0

current_call_mobile = {"value": 919732651232}
current_call_uuid = {"value": ""}
call_state = {}
active_calls = {}


async def start_call_recording(call_uuid: str):
    """Start recording via Plivo REST API — works with bidirectional streams."""
    if not call_uuid:
        print("⚠️ No call UUID — skipping recording")
        return
    url = f"https://api.plivo.com/v1/Account/{PLIVO_AUTH_ID}/Call/{call_uuid}/Record/"
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                url,
                auth=(PLIVO_AUTH_ID, PLIVO_AUTH_TOKEN),
                json={
                    "time_limit": 3600,
                    "file_format": "mp3",
                    "callback_url": f"{BASE_URL}/recording",
                    "callback_method": "POST",
                }
            )
            print(f"🎙️ Recording started: {resp.status_code} {resp.text}")
    except Exception as e:
        print(f"❌ Start recording error: {e}")


async def process_audio_direct(
    user_text: str, detected_lang: str,
    plivo_ws: WebSocket, caller_mobile: int,
    call_id: int, stop_event: asyncio.Event,
    is_bot_speaking: dict, stream_id: str = None,
    playback_state: dict = None
):
    t0 = time.time()
    print("🎤 USER:", user_text, "| LANG:", detected_lang)

    if call_id not in active_calls:
        return

    try:
        if caller_mobile not in call_state:
            call_state[caller_mobile] = {"first_prompt_done": False}

        state = call_state[caller_mobile]
        details = get_policy_by_mobile(caller_mobile)

        if not details:
            is_bot_speaking["value"] = True
            stop_event.clear()
            await stream_tts_to_plivo(
                "Mujhe aapki policy nahi mili. Kripya helpline pe call karein.",
                plivo_ws, stop_event, stream_id, playback_state
            )
            is_bot_speaking["value"] = False
            return

        expiry = normalize_date_for_speech(details.get("expiry"), "hi")
        policy = details.get("policy_type")
        name = details.get("name")
        reply_text = ""
        t = to_hinglish(user_text).lower()

        if not state["first_prompt_done"]:
            if is_voicemail(user_text):
                print("📵 Voicemail detected → stopping bot")
                return
            elif any(x in t for x in ["hello"]):
                reply_text = f"Namaste, kya meri baat {name} ji se ho rahi hai?"
            elif any(x in t for x in ["nahi", "no", "mat", "band","nahaeen"]):
                reply_text = "Koi baat nahi ji. Kya main aapka naam confirm kar sakti hoon?"
                state["first_prompt_done"] = True
            elif any(x in t for x in ["who","where", "kya", "kaun"]):
                reply_text = f"I am riya, from Bajaj General Insurance. Aapki {policy} policy {expiry} ko expire hone wali hai. Kya aap abhi renew karne ke liye ready hain?"
                state["first_prompt_done"] = True
            elif any(x in t for x in ["haan", "yes", "boliye", "hanji", "ha", "bilkul", "zaroor", "ji"]):
                reply_text = (
                    f"Aapki {policy} policy {expiry} ko expire hone wali hai... "
                    "Kya aap abhi renew karne ke liye ready hain?"
                )
                state["first_prompt_done"] = True



        if reply_text:
            print(f"🤖 BOT: {reply_text}")
            is_bot_speaking["value"] = True
            stop_event.clear()
            await stream_tts_to_plivo(reply_text, plivo_ws, stop_event, stream_id, playback_state)
            is_bot_speaking["value"] = False
        else:
            if is_voicemail(user_text):
                print("📵 Voicemail detected → stopping bot")
                return

            state["first_prompt_done"] = True
            print(f"🔍 RAG streaming... ({time.time()-t0:.2f}s since user spoke)")
            is_bot_speaking["value"] = True
            stop_event.clear()

            try:
                async for sentence in answer_with_rag_sentences(user_text, caller_mobile, detected_lang):
                    if stop_event.is_set():
                        break
                    print(f"🤖 BOT: {sentence} ({time.time()-t0:.2f}s)")
                    await stream_tts_to_plivo(sentence, plivo_ws, stop_event, stream_id, playback_state)
            except Exception as e:
                print("❌ RAG error:", e)
                await stream_tts_to_plivo(
                    "Kuch technical samasya hai. Thodi der mein dobara try karein.",
                    plivo_ws, stop_event, stream_id, playback_state
                )

            is_bot_speaking["value"] = False

    except asyncio.CancelledError:
        print("⚡ Task cancelled — barge-in")
        is_bot_speaking["value"] = False
    except Exception as e:
        print("❌ Error:", e)
        import traceback
        traceback.print_exc()
        is_bot_speaking["value"] = False


async def plivo_handler(plivo_ws: WebSocket, caller_mobile: int):
    try:
        await plivo_ws.accept()
    except Exception as e:
        print(f"❌ Accept error: {e}")
        return

    call_id = id(plivo_ws)
    active_calls[call_id] = True
    call_state[caller_mobile] = {"first_prompt_done": False}

    print("📞 WebSocket connected | Caller:", caller_mobile)

    stop_event = asyncio.Event()
    is_bot_speaking = {"value": False}
    current_task = {"task": None}
    stream_state = {"stream_id": None}
    playback_state = {"until": 0.0}
    greeting_done = {"value": False}

    # =====================================================
    # REAL-WORLD BARGE-IN STATE
    # =====================================================
    noise_floor = {"rms": 300.0}

    barge_in_state = {
        "speech_count": 0,
        "min_chunks": 8,          # safer for noisy environment
        "triggered": False,
        "cooldown": False,
        "buffer": [],
        "pending_until": 0.0,
        "last_possible_time": 0.0,
    }

    def is_speech_like_for_bargein(pcm_chunk: bytes) -> bool:
        """
        Only detects POSSIBLE speech.
        This should NOT directly stop the bot.
        Final confirmation must come from STT text.
        """
        try:
            rms = audioop.rms(pcm_chunk, 2)
            zcr = audioop.cross(pcm_chunk, 2)
        except Exception:
            return False

        # Learn background noise when not very loud
        if rms < 1800:
            noise_floor["rms"] = 0.97 * noise_floor["rms"] + 0.03 * rms

        dynamic_threshold = max(2200, noise_floor["rms"] * 4.0)

        # print("BARGE CHECK | RMS:", rms, "ZCR:", zcr, "TH:", dynamic_threshold)

        return (
            rms > dynamic_threshold and
            15 <= zcr <= 90
        )

    def is_valid_bargein_text(text: str) -> bool:
        """
        STT confirmation filter.
        Reject tiny/filler/noise text so background noise does not stop bot.
        """
        if not text:
            return False

        t = text.strip().lower()

        if len(t) < 3:
            return False

        noise_words = {
            "uh", "um", "hmm", "mmm", "ah", "aa", "haan",
            "thank you", "thanks", "ok", "okay"
        }

        if t in noise_words:
            return False

        # If only one very short word during bot speech, ignore
        words = t.split()
        if len(words) == 1 and len(words[0]) <= 3:
            return False

        return True

    stt = create_stt_stream()
    loop = asyncio.get_event_loop()

    async def on_speech(text, lang):
        if call_id not in active_calls:
            return

        text = (text or "").strip()
        if not text:
            return

        if not greeting_done["value"]:
            print(f"⏭️ Ignoring pre-greeting speech: '{text}'")
            return

        bot_was_active = (
            is_bot_speaking["value"]
            or time.time() < playback_state["until"]
            or time.time() < barge_in_state.get("pending_until", 0.0)
        )

        # =====================================================
        # IMPORTANT:
        # During bot speech, do not stop bot unless STT confirms real text
        # =====================================================
        if bot_was_active and not is_valid_bargein_text(text):
            print(f"⏭️ Ignoring noise/filler STT during bot speech: '{text}'")
            return

        print(f"🎙️ Confirmed speech: '{text}' | bot_active: {bot_was_active}")

        # Now we can stop bot because STT confirmed user speech
        stop_event.set()

        if bot_was_active:
            await send_clear_audio(plivo_ws, stream_state.get("stream_id"))
            playback_state["until"] = 0.0

        if current_task["task"] and not current_task["task"].done():
            current_task["task"].cancel()
            try:
                await current_task["task"]
            except (asyncio.CancelledError, Exception):
                pass
            print(f"🛑 Bot stopped after STT confirmation: '{text}'")

        is_bot_speaking["value"] = False
        playback_state["until"] = 0.0

        barge_in_state["triggered"] = False
        barge_in_state["speech_count"] = 0
        barge_in_state["buffer"] = []
        barge_in_state["cooldown"] = True

        stop_event.clear()
        barge_in_state["cooldown"] = False

        current_task["task"] = asyncio.create_task(
            process_audio_direct(
                text,
                lang,
                plivo_ws,
                caller_mobile,
                call_id,
                stop_event,
                is_bot_speaking,
                stream_id=stream_state.get("stream_id"),
                playback_state=playback_state,
            )
        )

    stt.set_callback(on_speech, loop)

    try:
        async for msg in plivo_ws.iter_text():
            data = json.loads(msg)
            event = data.get("event")

            if event == "media":
                chunk = base64.b64decode(data["media"]["payload"])

                try:
                    pcm_chunk = audioop.ulaw2lin(chunk, 2)
                except Exception as e:
                    print("❌ ulaw2lin error:", e)
                    continue

                bot_active = (
                    is_bot_speaking["value"]
                    or time.time() < playback_state["until"]
                )

                # =====================================================
                # BOT SPEAKING: only detect possible speech
                # Do NOT stop bot here.
                # =====================================================
                if bot_active:
                    if barge_in_state["cooldown"]:
                        continue

                    # Already possible speech detected.
                    # Feed audio to STT and wait for text confirmation.
                    if barge_in_state["triggered"]:
                        stt.push_audio(pcm_chunk)

                        # Timeout possible barge-in if STT gives no text
                        if time.time() > barge_in_state["pending_until"]:
                            print("⏭️ Possible barge-in expired, no STT confirmation")
                            barge_in_state["triggered"] = False
                            barge_in_state["speech_count"] = 0
                            barge_in_state["buffer"] = []

                        continue

                    # First gate: audio only says "possible speech"
                    if is_speech_like_for_bargein(pcm_chunk):
                        barge_in_state["speech_count"] += 1
                        barge_in_state["buffer"].append(pcm_chunk)
                    else:
                        barge_in_state["speech_count"] = 0
                        barge_in_state["buffer"] = []

                    # Possible speech detected
                    if barge_in_state["speech_count"] >= barge_in_state["min_chunks"]:
                        print("🎧 Possible barge-in audio detected, waiting for STT text")

                        barge_in_state["triggered"] = True
                        barge_in_state["speech_count"] = 0
                        barge_in_state["pending_until"] = time.time() + 1.4
                        barge_in_state["last_possible_time"] = time.time()

                        # Feed buffered audio to STT
                        for buffered in barge_in_state["buffer"]:
                            stt.push_audio(buffered)

                        barge_in_state["buffer"] = []

                    # IMPORTANT:
                    # no stop_event.set()
                    # no send_clear_audio()
                    # no cancel task here

                # =====================================================
                # BOT NOT SPEAKING: normal user speech
                # =====================================================
                else:
                    if stop_event.is_set():
                        stop_event.clear()

                    barge_in_state["triggered"] = False
                    barge_in_state["speech_count"] = 0
                    barge_in_state["buffer"] = []

                    stt.push_audio(pcm_chunk)

            elif event == "start":
                start_data = data.get("start", {})
                stream_state["stream_id"] = start_data.get("streamId")

                print(f"▶️ Stream started | streamId: {stream_state['stream_id']}")

                asyncio.ensure_future(
                    start_call_recording(current_call_uuid.get("value", ""))
                )

                barge_in_state["cooldown"] = False

                details = get_policy_by_mobile(caller_mobile)

                if details:
                    name = details.get("name", "")
                    greeting_text = f"Namaste, kya meri baat {name} ji se ho rahi hai?"
                else:
                    greeting_text = (
                        "Namaste! Main Riya bol rahi hoon. "
                        "Kya main aapki madad kar sakti hoon?"
                    )

                is_bot_speaking["value"] = True
                barge_in_state["cooldown"] = True

                await stream_tts_to_plivo(
                    greeting_text,
                    plivo_ws,
                    stop_event,
                    stream_state["stream_id"],
                    playback_state,
                )

                is_bot_speaking["value"] = False
                greeting_done["value"] = True

                barge_in_state["cooldown"] = False
                barge_in_state["speech_count"] = 0
                barge_in_state["buffer"] = []
                barge_in_state["triggered"] = False
                barge_in_state["pending_until"] = 0.0

            elif event == "clearedAudio":
                print("🧹 Plivo confirmed: audio cleared")

            elif event == "stop":
                print("🛑 Stop event")
                break

    except WebSocketDisconnect:
        print("📞 WebSocket disconnected")

    except Exception as e:
        print("❌ WebSocket error:", e)
        import traceback
        traceback.print_exc()

    finally:
        active_calls.pop(call_id, None)

        try:
            stt.close()
        except Exception:
            pass

        if current_task["task"]:
            current_task["task"].cancel()

        try:
            await plivo_ws.close()
        except Exception:
            pass

        print("📞 WebSocket closed")


@app.websocket("/audiostream")
async def websocket_endpoint(ws: WebSocket):
    mobile = current_call_mobile.get("value", 919732651232)
    await plivo_handler(ws, mobile)


@app.api_route("/answer", methods=["GET", "POST"])
async def answer(request: Request):
    try:
        form = await request.form()
        from_number = form.get("To", "")
        call_uuid = form.get("RequestUUID", "")
        current_call_uuid["value"] = call_uuid
        if from_number:
            mobile = get_caller_mobile(from_number)
            current_call_mobile["value"] = mobile
            print(f"📞 Inbound from: {from_number} → mobile: {mobile} | UUID: {call_uuid}")
    except Exception as e:
        print("❌ Answer error:", e)

    NGROK_WS = f"wss://acorned-retral-adelynn.ngrok-free.dev/audiostream"

    return Response(
        f"""<Response>
            <Stream
                streamTimeout="3600"
                keepCallAlive="true"
                bidirectional="true"
                contentType="audio/x-mulaw;rate=8000"
                statusCallbackUrl="{BASE_URL}/callbacks">
                {NGROK_WS}
            </Stream>
        </Response>""",
        media_type="application/xml"
    )


@app.api_route("/callbacks", methods=["GET", "POST"])
async def callbacks(request: Request):
    try:
        body = await request.form()
        print("📣 Callback:", dict(body))
    except:
        pass
    return Response("OK", media_type="text/plain")


@app.api_route("/recording", methods=["GET", "POST"])
async def recording(request: Request):
    try:
        body = await request.form()
        raw = dict(body)
        print("🎙️ Recording callback raw:", raw)

        if "response" in raw:
            data = json.loads(raw["response"])
        else:
            data = raw

        record_url = data.get("record_url")
        recording_id = data.get("recording_id")
        duration = data.get("recording_duration")
        print(f"🎙️ RecordUrl: {record_url}")
        print(f"🎙️ RecordingID: {recording_id}")
        print(f"🎙️ Duration: {duration}s")

        # Download recording with Plivo auth
        if record_url:
            async with httpx.AsyncClient() as client:
                resp = await client.get(
                    record_url,
                    auth=(PLIVO_AUTH_ID, PLIVO_AUTH_TOKEN),
                    follow_redirects=True
                )
                if resp.status_code == 200 and len(resp.content) > 0:
                    import os
                    os.makedirs("recordings", exist_ok=True)
                    filename = f"recordings/{recording_id}.mp3"
                    with open(filename, "wb") as f:
                        f.write(resp.content)
                    print(f"✅ Recording saved: {filename} ({len(resp.content)} bytes)")
                else:
                    print(f"❌ Download failed: {resp.status_code} ({len(resp.content)} bytes)")
    except Exception as e:
        print("❌ Recording callback error:", e)
    return Response("OK", media_type="text/plain")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

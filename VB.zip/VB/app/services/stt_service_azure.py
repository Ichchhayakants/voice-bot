import asyncio
import time
import re
import azure.cognitiveservices.speech as speechsdk

from app.config.settings import AZURE_SPEECH_KEY, AZURE_REGION

# =========================
# LANGUAGE DETECTION LOGIC
# =========================

_DEVANAGARI_RE = re.compile(r'[\u0900-\u097F]')

english_patterns = [
    "can you speak in english",
    "please speak in english",
    "speak in english",
    "talk in english",
    "english please",
    "speak english",
    "in english"
]

# 🔥 global lock (reset when app restarts / call resets)
_language_lock = None


def _detect_lang(text: str) -> str:
    global _language_lock

    text = (text or "").strip()
    lower_text = text.lower()
    words = text.split()

    # ✅ 1. If already locked → ALWAYS return it
    if _language_lock:
        return _language_lock

    # ✅ 2. Explicit English request → lock permanently
    if any(p in lower_text for p in english_patterns):
        _language_lock = "en-IN"
        return "en-IN"

    # ✅ 3. Normal detection (first time only)
    if _DEVANAGARI_RE.search(text):
        detected = "hi-IN"
    elif len(words) <= 1:
        detected = "hi-IN"
    elif all(word.isascii() for word in words):
        detected = "en-IN"
    else:
        detected = "hi-IN"

    # ✅ 4. OPTIONAL: lock if English detected
    if detected == "en-IN":
        _language_lock = "en-IN"

    return detected


def reset_language_lock():
    global _language_lock
    _language_lock = None


# =========================
# AZURE STT STREAM
# =========================

class AzureSTTStream:
    def __init__(self):
        self.detected_lang = "hi-IN"
        self._callback = None
        self._loop = None
        self._connected = False
        self._closing = False

        self._last_transcript = ""
        self._last_sent_time = 0

        self._partial_text = ""
        self._sentence_timer = None

        # Azure speech config
        self.speech_config = speechsdk.SpeechConfig(
            subscription=AZURE_SPEECH_KEY,
            region=AZURE_REGION
        )

        # 🔥 Low-latency tuning
        self.speech_config.set_property(
            speechsdk.PropertyId.SpeechServiceConnection_InitialSilenceTimeoutMs, "600"
        )
        self.speech_config.set_property(
            speechsdk.PropertyId.SpeechServiceConnection_EndSilenceTimeoutMs, "400"
        )
        self.speech_config.set_property(
            speechsdk.PropertyId.Speech_SegmentationSilenceTimeoutMs, "250"
        )

        # Base recognition language
        # Keep hi-IN as base, detect English from transcript text exactly like Deepgram logic
        self.speech_config.speech_recognition_language = "hi-IN"

        # 8k telephony PCM
        self.audio_format = speechsdk.audio.AudioStreamFormat(
            samples_per_second=8000,
            bits_per_sample=16,
            channels=1
        )
        self.stream = speechsdk.audio.PushAudioInputStream(self.audio_format)
        self.audio_config = speechsdk.audio.AudioConfig(stream=self.stream)

        self.recognizer = speechsdk.SpeechRecognizer(
            speech_config=self.speech_config,
            audio_config=self.audio_config
        )

        # Events
        self.recognizer.recognizing.connect(self._on_recognizing)
        self.recognizer.recognized.connect(self._on_recognized)
        self.recognizer.session_started.connect(self._on_session_started)
        self.recognizer.session_stopped.connect(self._on_session_stopped)
        self.recognizer.canceled.connect(self._on_canceled)

    # =========================
    # EVENT HANDLERS
    # =========================

    def _on_session_started(self, evt):
        self._connected = True
        print("✅ Azure streaming connected")

    def _on_session_stopped(self, evt):
        self._connected = False
        print("📞 Azure session stopped")

    def _on_canceled(self, evt):
        self._connected = False
        print(f"❌ Azure canceled: {evt.reason}")
        try:
            if evt.error_details:
                print(f"❌ Azure error details: {evt.error_details}")
        except Exception:
            pass

    def _on_recognizing(self, evt):
        try:
            partial = (evt.result.text or "").strip()
            if partial:
                self._partial_text = partial
                print(f"⚡ Partial: '{partial}'")
        except Exception as e:
            print(f"❌ recognizing error: {e}")

    def _on_recognized(self, evt):
        try:
            if evt.result.reason != speechsdk.ResultReason.RecognizedSpeech:
                return

            text = (evt.result.text or "").strip()
            if not text:
                return

            # detect language from transcript text
            self.detected_lang = _detect_lang(text)

            print(f"🎙️ STT [{self.detected_lang}]: '{text}'")

            # Cancel previous timer and send after tiny delay
            # This behaves closer to Deepgram final-chunk handling
            if self._sentence_timer:
                self._sentence_timer.cancel()

            if self._loop:
                self._sentence_timer = self._loop.call_later(
                    0.20, self._emit_final_text, text
                )

        except Exception as e:
            print(f"❌ recognized error: {e}")

    # =========================
    # FINAL EMIT LOGIC
    # =========================

    def _emit_final_text(self, text: str):
        if not text:
            return

        now = time.time()

        # Same duplicate suppression idea as Deepgram
        if text == self._last_transcript and (now - self._last_sent_time) <= 1.0:
            print(f"⏭️ Skip: '{text}'")
            return

        self._last_transcript = text
        self._last_sent_time = now

        print(f"✅ FINAL: '{text}'")

        if self._callback and self._loop:
            asyncio.run_coroutine_threadsafe(
                self._callback(text, self.detected_lang),
                self._loop
            )

    # =========================
    # PUBLIC API
    # =========================

    def set_callback(self, callback, loop):
        self._callback = callback
        self._loop = loop

        if not self._connected and not self._closing:
            self.recognizer.start_continuous_recognition()
            print("✅ Azure STT started")

    def push_audio(self, pcm_chunk: bytes):
        if self._closing:
            return
        try:
            self.stream.write(pcm_chunk)
        except Exception as e:
            print(f"❌ push_audio error: {e}")

    def get_text(self):
        return "", self.detected_lang

    def close(self):
        self._closing = True
        self._connected = False

        try:
            if self._sentence_timer:
                self._sentence_timer.cancel()
        except Exception:
            pass

        try:
            self.stream.close()
        except Exception:
            pass

        try:
            self.recognizer.stop_continuous_recognition()
        except Exception:
            pass

    # Optional helper if you want per-call reset
    def reset_language(self):
        reset_language_lock()
        self.detected_lang = "hi-IN"


def create_stt_stream():
    return AzureSTTStream()
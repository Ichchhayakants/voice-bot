import asyncio
import base64
import json
import audioop
import re
from fastapi import FastAPI, WebSocket, Request, WebSocketDisconnect
from fastapi.responses import Response
from fastapi.staticfiles import StaticFiles
from app.services.stt_service import create_stt_stream
from app.services.rag_services_1 import answer_with_rag_stream
from app.services.tts_stream import stream_tts_to_plivo
from app.services.policy_data import get_policy_by_mobile, normalize_date_for_speech, policy_df

app = FastAPI()
app.mount("/audio", StaticFiles(directory="app"), name="audio")

print("📊 Mobile No sample:", policy_df["Mobile No"].head(10).tolist())

VOICEMAIL_KEYWORDS = [
    "forwarded to", "not available", "record your message",
    "after the beep", "please leave", "hang up",
    "voicemail", "message after tone"
]

def is_voicemail(text: str) -> bool:
    t = text.lower()
    return any(k in t for k in VOICEMAIL_KEYWORDS)

DEV_MAP = {
    "हां": "haan",
    "हाँ": "haan",
    "जी": "ji",
    "बोलो": "bolo",
    "बोलिए": "boliye"
}

def to_hinglish(text):
    for k, v in DEV_MAP.items():
        text = text.replace(k, v)
    return text.lower()

class UserQueryAggregator:
    def __init__(self, loop, callback):
        self._loop = loop
        self._callback = callback
        self._buffer = ""
        self._timer = None

    async def add(self, text, lang):
        self._buffer += " " + text

        # cancel previous timer
        if self._timer:
            self._timer.cancel()

        # wait for user to finish speaking
        self._timer = self._loop.call_later(
            1.5, self._finalize, lang
        )

    def _finalize(self, lang):
        query = self._buffer.strip()
        self._buffer = ""

        print(f"🎤 FINAL USER QUERY: {query}")

        asyncio.run_coroutine_threadsafe(
            self._callback(query, lang),
            self._loop
        )


def get_caller_mobile(raw_number: str) -> int:
    raw = str(raw_number).strip().lstrip("+")
    excel_numbers = policy_df["Mobile No"].dropna().astype(str).tolist()
    if raw in excel_numbers:
        return int(raw)
    if raw.startswith("91") and raw[2:] in excel_numbers:
        return int(raw[2:])
    if ("91" + raw) in excel_numbers:
        return int("91" + raw)
    print(f"⚠️ No Excel match for: {raw}")
    return int(raw) if str(raw).isdigit() else 0

current_call_mobile = {"value": 919732651232}
call_state = {}
active_calls = {}

async def process_audio_direct(user_text: str, detected_lang: str, plivo_ws: WebSocket, caller_mobile: int, call_id: int):
    print("🎤 USER:", user_text, "| LANG:", detected_lang)

    if call_id not in active_calls:
        print("⚠️ Call already ended — skip")
        return

    try:
        if caller_mobile not in call_state:
            call_state[caller_mobile] = {"first_prompt_done": False}

        state = call_state[caller_mobile]
        details = get_policy_by_mobile(caller_mobile)

        if not details:
            await stream_tts_to_plivo(
                "Mujhe aapki policy nahi mili. Kripya helpline pe call karein.",
                plivo_ws
            )
            return

        expiry = normalize_date_for_speech(details.get("expiry"), "hi")
        policy = details.get("policy_type")
        name = details.get("name")
        reply_text = ""
        t = user_text.lower()
        t = to_hinglish(t)
        print("t",t) 

        if not state["first_prompt_done"]:
            if is_voicemail(user_text):
                print("📵 Voicemail detected → stopping bot")
                return  # or hangup / stop TTS
            
            elif any(x in t for x in ["हाँ", "yes", "haan", "बोलिए", "हांजी", "ha", "bilkul", "zaroor","ha", "haa", "haan", "yes", "ok", "bolo", "boliye"]):
                reply_text = (
                    f"Mein Rahul hu Bajaj General Insurance se... "
                    f"Aapki health policy five April two thousend twenty six ko expire hone wali hai..."
                    "Kya aap abhi renew karna chahenge..."
                )
                state["first_prompt_done"] = True
            elif any(x in t for x in ["नहीं","no", "nahi", "mat", "band"]):
                reply_text = (
                    f"Main Rahul hoon...."
                    " shayad thodi galti ho gaya..."
                    "Kya mai aapka naam jaan sakta hoon?"
                    )
                state["first_prompt_done"] = True
            else:
                reply_text = await answer_with_rag_stream(user_text, caller_mobile, detected_lang)
                state["first_prompt_done"] = True
                
        if not reply_text:
            print("🔍 RAG se answer le raha hoon...")
            if is_voicemail(user_text):
                print("📵 Voicemail detected → stopping bot")
                return  # or hangup / stop TTS
            try:
                reply_text = await answer_with_rag_stream(user_text, caller_mobile, detected_lang)
            except Exception as e:
                print("❌ RAG error:", e)
                reply_text = "Kuch technical samasya hai. Thodi der mein dobara try karein."

        if reply_text:
            print("🤖 BOT:", reply_text)
            await stream_tts_to_plivo(reply_text, plivo_ws)

    except Exception as e:
        print("❌ Error:", e)
        import traceback
        traceback.print_exc()


async def plivo_handler(plivo_ws: WebSocket, caller_mobile: int):
    try:
        await plivo_ws.accept()
    except Exception as e:
        print(f"❌ Accept error: {e}")
        return

    call_id = id(plivo_ws)
    active_calls[call_id] = True
    call_state[caller_mobile] = {"first_prompt_done": False}  # ✅ Reset
    print("📞 WebSocket connected | Caller:", caller_mobile)

    stt = create_stt_stream()
    loop = asyncio.get_event_loop()

    # async def on_speech(text, lang):
    #     if call_id in active_calls:
    #         await process_audio_direct(text, lang, plivo_ws, caller_mobile, call_id)

    # Create aggregator
    aggregator = UserQueryAggregator(
        loop,
        lambda final_text, lang: process_audio_direct(
            final_text, lang, plivo_ws, caller_mobile, call_id
        )
    )

    async def on_speech(text, lang):
        if call_id in active_calls:
            await aggregator.add(text, lang)

    stt.set_callback(on_speech, loop)


    details = get_policy_by_mobile(caller_mobile)
    if details:
        name = details.get("name", "")
        greeting_text = "Hello... kya main Sandeep ji se baat kar raha hoon..."
    else:
        greeting_text = "Namaste! Main Rahul hu. Kya main aapki madad kar sakta hoon?"

    await stream_tts_to_plivo(greeting_text, plivo_ws)
    await asyncio.sleep(0.5)

    try:
        async for msg in plivo_ws.iter_text():
            data = json.loads(msg)
            event = data.get("event")

            if event == "media":
                chunk = base64.b64decode(data["media"]["payload"])
                
                try:
                    pcm_chunk = audioop.ulaw2lin(chunk, 2)
                except Exception as e:
                    print("❌ ulaw2lin error:", e)
                    continue
                stt.push_audio(pcm_chunk)  # ✅ Sirf push — callback handle karega

            elif event == "stop":
                print("🛑 Stop event")
                break
            elif event == "start":
                print("▶️ Stream started")

    except WebSocketDisconnect:
        print("📞 WebSocket disconnected")
    except Exception as e:
        print("❌ WebSocket error:", e)
    finally:
        active_calls.pop(call_id, None)
        stt.close()
        try:
            await plivo_ws.close()
        except:
            pass
        print("📞 WebSocket closed")


@app.websocket("/audiostream")
async def websocket_endpoint(ws: WebSocket):
    mobile = current_call_mobile.get("value", 919732651232)
    await plivo_handler(ws, mobile)


@app.api_route("/answer", methods=["GET", "POST"])
async def answer(request: Request):
    try:
        form = await request.form()
        from_number = form.get("To", "")
        if from_number:
            mobile = get_caller_mobile(from_number)
            current_call_mobile["value"] = mobile
            print(f"📞 Inbound from: {from_number} → mobile: {mobile}")
    except Exception as e:
        print("❌ Answer error:", e)

    NGROK_WS = "wss://acorned-retral-adelynn.ngrok-free.dev/audiostream"
    return Response(
        f"""<Response>
            <Stream
                streamTimeout="3600"
                keepCallAlive="true"
                bidirectional="true"
                record="true"
                recordingCallbackUrl="https://acorned-retral-adelynn.ngrok-free.dev/recording"
                contentType="audio/x-mulaw;rate=8000"
                statusCallbackUrl="https://acorned-retral-adelynn.ngrok-free.dev/callbacks">
                {NGROK_WS}
            </Stream>
        </Response>""",
        media_type="application/xml"
    )


@app.api_route("/callbacks", methods=["GET", "POST"])
async def callbacks(request: Request):
    try:
        body = await request.form()
        print("📣 Callback:", dict(body))
    except:
        pass
    return Response("OK", media_type="text/plain")


@app.api_route("/recording", methods=["GET", "POST"])
async def recording(request: Request):
    try:
        body = await request.form()
        data = dict(body)
        print(data)
        print("🎙️ Recording URL:", data.get("RecordUrl", "No URL"))
    except:
        pass
    return Response("OK", media_type="text/plain")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
# TWILIO_SID = "AC9c854b0f3b7239fbca3403b61903072b"
# TWILIO_TOKEN = "3d805fb15cac51d2d4986a2e06bfef14"

Plivo_ID = "MAN2I1ZTIZODA2MGMWMJ"
Plivo_token = "YjI5MTUzZDItNWUxZC00NTYxLTkzOGItNGU2MDcx"

#AZURE_SPEECH_KEY = "02G732TmS99Rp6M27yCk9qV4dbUdRyhho5fq0OroehUN57YjwQmGJQQJ99BLACGhslBXJ3w3AAAYACOGIXfM"

# AZURE_SPEECH_KEY = "FSjXKJZLvRjQnGaHZ1DF4gZB47TCdO3xTK04iFj3iqbDzLH6WgLhJQQJ99CDACGhslBXJ3w3AAAYACOG7KQO"
# AZURE_REGION = "centralindia"

PUBLIC_URL = "https://acorned-retral-adelynn.ngrok-free.dev"
FAISS_DIR = "./vectordb5"

POLICY_EXCEL_PATH = "app\services\insurance_data.xlsx"

GROQ_API_KEY = "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"
TWILIO_MESSAGING_SID = "MGcd5da607923b9e56df3489669015ec77"
MODEL_NAME = "openai/gpt-oss-20b"

Deepgram_key = "8a1a81dfcb5f3074748b61471bd8df45ac2b911c"
SPEECHMATICS_API_KEY = "bzjG6DXGwzrd0UfqV9TdnDJzR3l0Ukxc"
API_KEY_ele_lab = "sk_c8093870dd96ea357916849bbbb9378b27cc64c8744c7058"

Sarvam_api_key = "sk_fjhra58e_2SG2lLjUepc8OnJCatudPrpL"

# VOICE_ID = "jUjRbhZWoMK4aDciW36V" 
# VOICE_ID = "CwhRBWXzGAHq8TQ4Fs17"  ### Male voice

# VOICE_ID = "zmh5xhBvMzqR4ZlXgcgL"
VOICE_ID =   "C2S5J6WvmHnrQWjUu6Rg" 
# VOICE_ID = "7eFpSZXqNUHJQJe7B9pS"  ### Final feMale voice
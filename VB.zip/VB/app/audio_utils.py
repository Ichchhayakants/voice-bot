import audioop
import base64

def mulaw_to_pcm(data):
    return audioop.ulaw2lin(data, 2)

def pcm_to_mulaw(pcm):
    mulaw = audioop.lin2ulaw(pcm, 2)
    return base64.b64encode(mulaw).decode()